package vn.tayjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TayjavaSampleCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TayjavaSampleCodeApplication.class, args);
	}

}
